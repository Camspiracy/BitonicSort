#ifndef BITONIC_H
#define BITONIC_H

bool validate_sort(int n, float *data);
void seq_bitonic(int n, float *data);

#endif 
